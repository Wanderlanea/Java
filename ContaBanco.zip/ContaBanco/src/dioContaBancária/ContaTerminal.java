package dioContaBancária;

import java.util.Scanner;

public class ContaTerminal {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.print("Por favor, digite seu nome: ");
        String nomeCliente = sc.nextLine();

        System.out.println();
        
        System.out.print("Por favor, digite o número da agência: ");
        String agencia = sc.nextLine();

        System.out.println();
        
        System.out.print("Por favor, digite sua conta: ");
        int conta = sc.nextInt();
        
        System.out.println();

        System.out.print("Por favor, digite seu saldo: ");
        double saldo = sc.nextDouble();

        System.out.println();
        
        System.out.printf("Olá %s, obrigado por criar uma conta em nosso banco, " +
                          "sua agência é %s, conta %d e seu saldo %.2f já está disponível para saque.%n", 
                          nomeCliente, agencia, conta, saldo);

        sc.close(); 
    }
}